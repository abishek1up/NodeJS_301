var mongoose = require('mongoose');

var RestaurantSchema = new mongoose.Schema({
  cuisine: { type: String },
  name: {type: String},
  restaurant_id: {type: Number},
  city:{ type: String }
}, { collection: 'restaurant' });

//minimum 3 letter title
RestaurantSchema.path('name').validate(function (value) {
  return value && value.length >= 3;
}, 'symbol should be minimum of 3 letters');

mongoose.model('Restaurant', RestaurantSchema)

module.exports = mongoose.model('Restaurant')